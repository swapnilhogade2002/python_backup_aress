import os

def list_files(directory):
    '''
    Lists all files in the specified directory.
    :param directory: The directory path.
    '''
    try:
        # List all files in the directory
        files = os.listdir(directory)

        # Filter out directories and list only files
        file = [file for file in files if os.path.isfile(os.path.join(directory, file))]

        # Print the list of files
        print("file directory: ", file)
        for file in files:
            print(file)

    except FileNotFoundError:
        print("Error: file not found")


if __name__ == "__main__":
    directory_path = input("Enter directory path: ")
    list_files(directory_path)
