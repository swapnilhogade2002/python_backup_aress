import csv

def read_csv(file):
    '''
    Reads and prints the contents of a CSV file.
    Args:
        file (str): The path to the CSV file to be read.
    '''
    try:
        with open(file, mode='r') as file:
            csv_reader = csv.reader(file)
            # Iterate over each row and print it
            for row in csv_reader:
                print(row)

    except FileNotFoundError:
        print(f"Error: File '{file}' not found.")
    except Exception as e:
        print(f"An error occurred: {e}")

if __name__ == "__main__":
    read_csv('read_csv_ass.csv')
