import math

class Shape:
    '''
    A base class representing a shape.
    '''
    def area(self):
        '''
        Abstract method to calculate the area of a shape.
        '''
        pass

class Circle(Shape):
    '''
    A class representing a circle.
    '''
    def __init__(self, radius):
        '''
        Initializes a Circle object with the given radius.
        '''
        self.radius = radius

    def area(self):
        '''
        Calculates the area of the circle.
        '''
        return math.pi * self.radius ** 2

class Rectangle(Shape):
    '''
    A class representing a rectangle.
    '''
    def __init__(self, width, height):
        '''
        Initializes a Rectangle object with the given width and height.
        '''
        self.width = width
        self.height = height

    def area(self):
        '''
        Calculates the area of the rectangle.
        '''
        return self.height * self.width

if __name__ == "__main__":
    # Create Circle and Rectangle objects
    circle = Circle(9)
    rectangle = Rectangle(9, 9)

    # Calculate and print areas
    print("Area of circle:", circle.area())
    print("Area of rectangle:", rectangle.area())
