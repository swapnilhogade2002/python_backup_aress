class BankAccount:
    '''
    A class representing a bank account.

    Attributes:
        account_number (str): The account number.
        account_holder (str): The account holder's name.
        account_balance (float): The account balance.
    '''

    def __init__(self, account_number, account_holder, account_balance):
        '''
        Initializes a BankAccount object with the given account details.

        Parameters:
            account_number (str): The account number.
            account_holder (str): The account holder's name.
            account_balance (float): The initial account balance.
        '''
        self.account_number = account_number
        self.account_holder = account_holder
        self.account_balance = account_balance

    def deposit_money(self, deposit):
        '''
        Deposits money into the account.

        Parameters:
            deposit (float): The amount to deposit.

        Returns:
            float: The updated account balance.
        '''
        self.account_balance += deposit
        print("Money Deposited successfully ! Account Balance is :", self.account_balance)
        return self.account_balance

    def withdraw_money(self, withdraw):
        '''
        Withdraws money from the account.

        Parameters:
            withdraw (float): The amount to withdraw.

        Returns:
            float: The updated account balance.
        '''
        if self.account_balance >= withdraw:
            self.account_balance -= withdraw
            print("Money Withdrawal successfully ! Account balance is:", self.account_balance)
        else:
            print("Insufficient funds.")
        return self.account_balance

    def check_balance(self):
        '''
        Checks and prints the current account balance.
        '''
        print("Account balance:", self.account_balance)
        return self.account_balance


if __name__ == "__main__":
    # Instantiate BankAccount object
    account = BankAccount("123456", "John Doe", 1000)

    # Test deposit, withdrawal, and balance check
    print("****** Bank Account Operation ******")
    print("--Account Details--")
    print("Account Number: ", account.account_number)
    print("Account Holder Name: ", account.account_holder, end="")
    print("\n")

    print("--Account Transection--")
    account.deposit_money(5000)
    account.withdraw_money(500)
    account.check_balance()
