def show_even_number(numbers):
    '''
    Filters a list of numbers to return only even numbers using a lambda function and prints them.

    Args:
        numbers (list): List of numbers.

    Returns:
        None
    '''
    even_numbers = list(filter(lambda x: x % 2 == 0, numbers))
    print("List of even numbers:")
    print(even_numbers)

if __name__ == "__main__":
    try:
        # Get a list of numbers from user input
        input_numbers = input("Enter a list of numbers separated by spaces: ").split()
        numbers = [int(num) for num in input_numbers]

        # Call the function with the user's input
        show_even_number(numbers)
    except ValueError:
        print("Error: Please enter valid numbers separated by spaces.")
