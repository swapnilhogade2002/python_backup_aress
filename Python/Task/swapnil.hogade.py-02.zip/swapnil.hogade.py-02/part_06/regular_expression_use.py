import re

def validate_email(email):
    '''
    Validate an email address using a regular expression pattern.

    Args:
        email (str): The email address to be validated.

    Returns:
        bool: True if the email address is valid, False otherwise.
    '''
    try:
        pattern = r'^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$'
        return re.match(pattern, email) is not None
    except Exception as e:
        print(f"An error occurred while validating the email address: {e}")
        return False

if __name__ == "__main__":
    try:
        email = input("Enter an email address: ")
        isValid = validate_email(email)
        if isValid:
            print(f"{email} is a VALID email address.")
        else:
            print(f"{email} is NOT a VALID email address.")
    except KeyboardInterrupt:
        print("\nProgram terminated by the user.")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")
