def read_number_from_file(number_list):
    '''
    Read numbers from a file and return them as a list.

    :param number_list: Name of the file containing numbers.
    :return: List of numbers read from the file.
    '''
    try:
        with open(number_list, 'r') as file:
            numbers = [float(line.strip()) for line in file if line.strip()]
            print(numbers)
            return numbers

    except FileNotFoundError:
        print(f"Error: file {number_list} not found")


def calculate_sum(numbers):
    '''
    Calculate the sum of numbers in a list.

    :param numbers: List of numbers.
    :return: Sum of numbers.
    '''
    sum_result = sum(numbers)
    print(sum_result)
    return sum_result


def write_sum_to_another_file(sum_result, write_list):
    '''
    Write the sum result to another file.

    :param sum_result: The sum to be written to the file.
    :param write_list: The filename where the sum will be written.
    :return: None
    '''
    try:
        with open(write_list, "w") as file:
            file.write("sum is : " + str(sum_result))
            print(f"Sum result has been written in {write_list}")
    except Exception as e:
        print(f"Error writing to file: '{e}'")


def main(number_list, write_list):
    '''
    Main function to read numbers from a file, calculate their sum,
    and write the sum result to another file.

    :param number_list: Name of the input file containing numbers.
    :param write_list: Name of the output file where the sum result will be written.
    :return: None
    '''
    numbers = read_number_from_file(number_list)
    if numbers:
        sum_result = calculate_sum(numbers)
        write_sum_to_another_file(sum_result, write_list)
        print(f"Sum of numbers has been written to '{write_list}'")


if __name__ == "__main__":
    input_filename = "number_list"
    output_filename = "write_list"
    main(input_filename, output_filename)
