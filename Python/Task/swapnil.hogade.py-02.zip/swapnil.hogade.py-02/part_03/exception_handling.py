def divide_number():
    '''
    Function to perform division operation based on user input.
    :return: None
    '''
    try:
        # Take user input for dividend and divisor
        dividend = float(input("Enter dividend: "))
        divisor = float(input("Enter divisor: "))

        # Perform division and print the result
        result = dividend / divisor
        print("Result of division operation is : ", result)

    # Handle specific errors
    except ZeroDivisionError:
        print("Error: cannot divide by zero.")
    except ValueError:
        print("Error: invalid input. Please enter a valid number.")

    # Handle unexpected errors
    except Exception as e:
        print("An unexpected error occurred:", e)


if __name__ == "__main__":
    divide_number()
