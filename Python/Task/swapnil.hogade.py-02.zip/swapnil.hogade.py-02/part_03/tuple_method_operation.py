def main():
    '''
    Main function to demonstrate tuple methods and operations.
    :return: None
    '''

    try:
        # Get elements for tuple 1
        tuple_1 = tuple(map(int, input("Enter elements for tuple 1 separated by spaces: ").split()))

        # Get elements for tuple 2
        tuple_2 = tuple(map(int, input("Enter elements for tuple 2 separated by spaces: ").split()))

        # Combine two tuples
        combine_tuple = tuple_1 + tuple_2
        print("Combined tuple:", combine_tuple)

        # Convert tuple to list
        tuple_to_list = list(combine_tuple)
        print("Tuple converted into list:", tuple_to_list)

        # Finding index of a specific element in the combined tuple
        element_to_find = int(input("Enter an element to find in the combined tuple: "))
        if element_to_find in combine_tuple:
            index = combine_tuple.index(element_to_find)
            print(f"Index of {element_to_find} in combined tuple:", index)
        else:
            print(f"Index of {element_to_find} not found in combined tuple")

    except ValueError:
        print("Error: Please enter valid integer elements.")
    except Exception as e:
        print("An error occurred:", e)


if __name__ == "__main__":
    main()
